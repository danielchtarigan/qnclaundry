									<form name="form_checkin" id="form_checkin" action="act/act_checkin.php">
                                        <div>                                        
                                          <input type="text" name="nota" id="nota" value="" class="form-control" placeholder="Scan Nota Disini.." style="width:50%; float:left;"/>      											
                                          <input type="submit" name="buttonpotongan" id="buttonpotongan" class="btn btn-success btkiloan" value="Save" style="width:20%; background-color:#FFF; color:#6C0;"/>
                                        </div>
								      </form>	
<?php 
include '../config.php';
$id = $_GET['id'];
?>


<body onload="print()">
	
</body>
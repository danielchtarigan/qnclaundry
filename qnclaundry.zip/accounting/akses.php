<?php 
if($lvl!='admin'){ ?>
	<script type="text/javascript">
	    alert('Akun Anda tidak bisa akses!');
		location.href="index.php";
	</script>
<?php
}

?>
<?php
session_start();
include 'config.php';
include 'auth.php';
include 'header.php';

require 'nav.php';
?>
 

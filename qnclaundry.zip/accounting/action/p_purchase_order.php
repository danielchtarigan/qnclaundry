<?php 
include '../config.php';



$con->query("INSERT INTO (nomor,id_requisition,item,unit_price,line_total,created_by,uom) VALUES ()");

?>
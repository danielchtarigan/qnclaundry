<?php
echo 'current_date';
?>
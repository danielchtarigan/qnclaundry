<html>
<head>
	
<?php 
include "header.php";
include "../config.php"; 

?>
</head>
<body>

</body>
</html>
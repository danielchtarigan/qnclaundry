<html>
	<head>
		<script src="js/highcharts.js"></script>
		<script src="js/data.js"></script>
		<script src="https://code.highcharts.com/modules/exporting.js"></script>				
	<title>Chart Platform highchart</title>
	</head>	
	<body>
		
	</body>
</html>
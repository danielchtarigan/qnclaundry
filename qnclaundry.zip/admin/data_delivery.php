
<?php
include '../reception/data_delivery.php';
?>
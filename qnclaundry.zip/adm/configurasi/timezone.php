<?php
$timezone = "Asia/Ujung_Pandang";
if(function_exists('date_default_timezone_set')) date_default_timezone_set($timezone);
$date=date('Y-m-d');
$time=date('H:i:s');
?>